import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'data_provider.dart';
import 'auth_provider.dart';
import 'navigation.dart';
import 'unified_header.dart';
import 'api_service.dart';

class TeamPage extends StatefulWidget {
  @override
  State<TeamPage> createState() => _TeamPageState();
}

class _TeamPageState extends State<TeamPage> {
  String _selectedFilterRole = '';
  String _searchQuery = '';
  final Map<int, bool> _expandedOwners = {};

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<DataProvider>().loadUsers();
    });
  }

  List<Map<String, dynamic>> _getFilteredUsers(List<Map<String, dynamic>> users) {
    return users.where((u) {
      final matchesRole = _selectedFilterRole.isEmpty || u['role'] == _selectedFilterRole;
      final name = (u['name'] ?? '').toLowerCase();
      final matchesSearch = _searchQuery.isEmpty || name.contains(_searchQuery.toLowerCase());
      return matchesRole && matchesSearch;
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    final userRole = auth.user?['role'] ?? '';
    final canEdit = userRole == 'Admin' || userRole == 'Owner';
    final isAdmin = userRole == 'Admin';

    return Scaffold(
      backgroundColor: const Color(0xFFfafaf5),
      body: Consumer<DataProvider>(
        builder: (context, dataProvider, _) {
          final users = dataProvider.users.isNotEmpty ? dataProvider.users : <Map<String, dynamic>>[];
          final isLoading = dataProvider.isLoading;
          final filteredUsers = _getFilteredUsers(users);
          final owners = users.where((u) => u['role'] == 'Owner').toList();

          return CustomScrollView(
            slivers: [
              UnifiedAppBar(title: 'Team', showBackButton: true, onBack: () => Navigator.pop(context)),
              if (isLoading)
                const SliverFillRemaining(child: Center(child: CircularProgressIndicator(color: Color(0xFF06402B))))
              else ...[
                SliverToBoxAdapter(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      children: [
                        TextField(
                          decoration: InputDecoration(hintText: 'Search by name...', prefixIcon: const Icon(Icons.search, size: 20), filled: true, fillColor: Colors.white, border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none)),
                          onChanged: (value) => setState(() => _searchQuery = value),
                        ),
                        const SizedBox(height: 8),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 12),
                          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12)),
                          child: DropdownButtonHideUnderline(
                            child: DropdownButton<String>(
                              value: _selectedFilterRole,
                              isExpanded: true,
                              hint: const Text('All Roles'),
                              items: const [
                                DropdownMenuItem(value: '', child: Text('All Roles')),
                                DropdownMenuItem(value: 'Owner', child: Text('Owner')),
                                DropdownMenuItem(value: 'Veterinarian', child: Text('Veterinarian')),
                                DropdownMenuItem(value: 'Shepherd', child: Text('Shepherd')),
                              ],
                              onChanged: (value) => setState(() => _selectedFilterRole = value ?? ''),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                if (filteredUsers.isEmpty)
                  const SliverFillRemaining(child: Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(Icons.group, size: 64, color: Color(0xFF717973)), SizedBox(height: 16), Text('No team members', style: TextStyle(fontSize: 18, color: Color(0xFF717973)))])))
                else ...[
                  SliverToBoxAdapter(child: Padding(padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8), child: Text('${filteredUsers.length} members', style: const TextStyle(color: Color(0xFF717973), fontSize: 12)))),
                  if (isAdmin && owners.isNotEmpty) ...[
                    SliverToBoxAdapter(child: Padding(padding: const EdgeInsets.fromLTRB(16, 16, 16, 8), child: Text('Owners & Their Teams', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Color(0xFF06402B))))),
                    ...owners.expand((owner) {
                      final ownerMembers = users.where((u) => u['managed_by'] == owner['id']).toList();
                      final ownerFiltered = ownerMembers.where((u) {
                        final matchesRole = _selectedFilterRole.isEmpty || u['role'] == _selectedFilterRole;
                        final name = (u['name'] ?? '').toLowerCase();
                        final matchesSearch = _searchQuery.isEmpty || name.contains(_searchQuery.toLowerCase());
                        return matchesRole && matchesSearch;
                      }).toList();
                      final isExpanded = _expandedOwners[owner['id']] ?? true;
                      final isOwnTeam = owner['id'] == auth.user?['id'];
                      
                      return [
                        SliverToBoxAdapter(
                          child: GestureDetector(
                            onTap: () => setState(() => _expandedOwners[owner['id']] = !isExpanded),
                            child: Container(
                              margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                              padding: const EdgeInsets.all(16),
                              decoration: BoxDecoration(
                                color: isOwnTeam ? const Color(0xFF735c00).withOpacity(0.1) : Colors.white,
                                borderRadius: BorderRadius.circular(16),
                                border: Border.all(color: isOwnTeam ? const Color(0xFF735c00) : Colors.transparent),
                              ),
                              child: Row(
                                children: [
                                  CircleAvatar(
                                    backgroundColor: isOwnTeam ? const Color(0xFF735c00) : const Color(0xFF06402B),
                                    child: Text((owner['name'] ?? '?')[0].toUpperCase(), style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                                  ),
                                  const SizedBox(width: 12),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Row(
                                          children: [
                                            Text(owner['name'] ?? '', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Color(0xFF06402B))),
                                            if (isOwnTeam) ...[
                                              const SizedBox(width: 8),
                                              Container(
                                                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                                decoration: BoxDecoration(color: const Color(0xFF0B5D3B), borderRadius: BorderRadius.circular(8)),
                                                child: const Text('Your Account', style: TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold)),
                                              ),
                                            ],
                                          ],
                                        ),
                                        Text(owner['email'] ?? '', style: const TextStyle(fontSize: 12, color: Color(0xFF717973))),
                                        const SizedBox(height: 4),
                                        Text('${ownerFiltered.length} team members', style: const TextStyle(fontSize: 11, color: Color(0xFF717973))),
                                      ],
                                    ),
                                  ),
                                  Icon(isExpanded ? Icons.expand_less : Icons.expand_more, color: Color(0xFF717973)),
                                ],
                              ),
                            ),
                          ),
                        ),
                        if (isExpanded && ownerFiltered.isNotEmpty)
                          ...ownerFiltered.map((member) => SliverToBoxAdapter(child: _buildTeamMemberCard(member, userRole, canEdit, auth, users, isAdmin))),
                        if (isExpanded && ownerFiltered.isEmpty)
                          SliverToBoxAdapter(child: Padding(padding: const EdgeInsets.symmetric(horizontal: 32), child: Text('No team members', style: TextStyle(color: Color(0xFF717973), fontSize: 13)))),
                      ];
                    }),
                  ],
                  if (!isAdmin)
                    SliverPadding(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      sliver: SliverList(delegate: SliverChildBuilderDelegate((context, index) => _buildTeamMemberCard(filteredUsers[index], userRole, canEdit, auth, users, isAdmin), childCount: filteredUsers.length)),
                    ),
                ],
                const SliverToBoxAdapter(child: SizedBox(height: 100)),
              ],
            ],
          );
        },
      ),
      floatingActionButton: canEdit
          ? FloatingActionButton.extended(
              onPressed: () {
                final dataProv = context.read<DataProvider>();
                _showAddMemberDialog(context, dataProv.users, userRole, canEdit, auth);
              },
              backgroundColor: const Color(0xFF06402B),
              icon: const Icon(Icons.person_add, color: Colors.white),
              label: const Text('Add Member', style: TextStyle(color: Colors.white)),
            )
          : null,
    );
  }

  Widget _buildTeamMemberCard(Map<String, dynamic> member, String userRole, bool canEdit, AuthProvider auth, List<Map<String, dynamic>> allUsers, bool isAdmin) {
    final roleColor = member['role'] == 'Veterinarian' ? Colors.purple : Colors.blue;
    
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12), border: Border.all(color: Colors.grey.shade200)),
      child: Row(
        children: [
          CircleAvatar(backgroundColor: roleColor, radius: 20, child: Icon(Icons.person, color: Colors.white, size: 20)),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(member['name'] ?? '', style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
                Text(member['email'] ?? '', style: TextStyle(fontSize: 12, color: Color(0xFF717973))),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(color: roleColor.withOpacity(0.1), borderRadius: BorderRadius.circular(8)),
            child: Text(member['role'] ?? '', style: TextStyle(fontSize: 10, fontWeight: FontWeight.bold, color: roleColor)),
          ),
          const SizedBox(width: 8),
          if (isAdmin)
            Switch(
              value: member['is_active'] == true,
              onChanged: canEdit ? (value) async {
                if (!context.mounted) return;
                final dataProv = context.read<DataProvider>();
                final messenger = ScaffoldMessenger.of(context);
                try {
                  final result = await ApiService.toggleUserStatus(member['id']);
                  messenger.showSnackBar(SnackBar(content: Text(result['message'] ?? 'Status updated')));
                  await Future.delayed(const Duration(milliseconds: 300));
                  await dataProv.loadUsers();
                } catch (e) {
                  messenger.showSnackBar(SnackBar(content: Text('Error: $e')));
                }
              } : null,
              activeColor: const Color(0xFF06402B),
            ),
          PopupMenuButton(
            icon: const Icon(Icons.more_vert, size: 20, color: Color(0xFF717973)),
            onSelected: (value) {
              if (value == 'edit') _showEditMemberDialog(context, member, userRole, canEdit, auth);
              else if (value == 'remove') _showDeleteConfirmation(context, member);
            },
            itemBuilder: (context) => [
              const PopupMenuItem(value: 'view', child: Text('View Profile', style: TextStyle(fontSize: 14))),
              const PopupMenuItem(value: 'edit', child: Text('Edit', style: TextStyle(fontSize: 14))),
              const PopupMenuItem(value: 'remove', child: Text('Remove', style: TextStyle(fontSize: 14, color: Color(0xFFba1a1a)))),
            ],
          ),
        ],
      ),
    );
  }

  void _showEditMemberDialog(BuildContext context, Map<String, dynamic> member, String userRole, bool canEdit, AuthProvider auth) {
    final nameController = TextEditingController(text: member['name'] ?? '');
    final emailController = TextEditingController(text: member['email'] ?? '');
    String selectedRole = member['role'] ?? 'Shepherd';

    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (ctx) => Container(
        padding: EdgeInsets.only(left: 24, right: 24, top: 24, bottom: MediaQuery.of(ctx).viewInsets.bottom + 24),
        decoration: const BoxDecoration(color: Colors.white, borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [const Text('Edit Team Member', style: TextStyle(fontFamily: 'Manrope', fontSize: 20, fontWeight: FontWeight.w800, color: Color(0xFF06402B))), IconButton(icon: const Icon(Icons.close), onPressed: () => Navigator.pop(ctx))]),
            const SizedBox(height: 24),
            TextField(controller: nameController, decoration: InputDecoration(labelText: 'Name', filled: true, fillColor: Color(0xFFf4f4ef), border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none))),
            const SizedBox(height: 16),
            TextField(controller: emailController, keyboardType: TextInputType.emailAddress, decoration: InputDecoration(labelText: 'Email', filled: true, fillColor: Color(0xFFf4f4ef), border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none))),
            const SizedBox(height: 16),
            DropdownButtonFormField(
              value: selectedRole,
              decoration: InputDecoration(labelText: 'Role', filled: true, fillColor: Color(0xFFf4f4ef), border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none)),
              items: _getAvailableRoles(userRole),
              onChanged: canEdit ? (value) {
                selectedRole = (value as String?) ?? 'Shepherd';
              } : null,
            ),
            const SizedBox(height: 24),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () async {
                  if (nameController.text.isEmpty || emailController.text.isEmpty) {
                    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Name and email are required')));
                    return;
                  }
                  try {
                    await ApiService.updateUser(member['id'], {'name': nameController.text, 'email': emailController.text, 'role': selectedRole, 'is_active': member['is_active'] ?? true});
                    if (ctx.mounted) Navigator.pop(ctx);
                    if (context.mounted) {
                      context.read<DataProvider>().loadUsers();
                      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Team member updated!')));
                    }
                  } catch (e) {
                    if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error: $e')));
                  }
                },
                style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF06402B), foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(vertical: 16), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
                child: const Text('Save Changes'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showDeleteConfirmation(BuildContext context, Map<String, dynamic> member) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Remove Team Member'),
        content: Text('Are you sure you want to remove ${member['name']}? This action cannot be undone.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          TextButton(
            onPressed: () async {
              Navigator.pop(ctx);
              try {
                await ApiService.deleteUser(member['id']);
                if (context.mounted) {
                  context.read<DataProvider>().loadUsers();
                  ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Team member removed')));
                }
              } catch (e) {
                if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error: $e')));
              }
            },
            child: const Text('Remove', style: TextStyle(color: Color(0xFFba1a1a))),
          ),
        ],
      ),
    );
  }

  List<DropdownMenuItem<String>> _getAvailableRoles(String userRole) {
    if (userRole == 'Admin') {
      return const [
        DropdownMenuItem(value: 'Admin', child: Text('Admin')),
        DropdownMenuItem(value: 'Owner', child: Text('Owner')),
        DropdownMenuItem(value: 'Veterinarian', child: Text('Veterinarian')),
        DropdownMenuItem(value: 'Shepherd', child: Text('Shepherd')),
      ];
    } else if (userRole == 'Owner') {
      return const [
        DropdownMenuItem(value: 'Veterinarian', child: Text('Veterinarian')),
        DropdownMenuItem(value: 'Shepherd', child: Text('Shepherd')),
      ];
    } else {
      return const [
        DropdownMenuItem(value: 'Shepherd', child: Text('Shepherd')),
      ];
    }
  }

  void _showAddMemberDialog(BuildContext context, List<Map<String, dynamic>> users, String userRole, bool canEdit, AuthProvider auth) {
    final nameController = TextEditingController();
    final emailController = TextEditingController();
    final passwordController = TextEditingController(text: 'Welcome123');
    String selectedRole = 'Shepherd';
    int? selectedOwnerId;
    final owners = users.where((u) => u['role'] == 'Owner').toList();

    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (ctx) => StatefulBuilder(
        builder: (sheetCtx, setSheetState) => Container(
          padding: EdgeInsets.only(left: 24, right: 24, top: 24, bottom: MediaQuery.of(sheetCtx).viewInsets.bottom + 24),
          decoration: const BoxDecoration(color: Colors.white, borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [const Text('Add Team Member', style: TextStyle(fontFamily: 'Manrope', fontSize: 20, fontWeight: FontWeight.w800, color: Color(0xFF06402B))), IconButton(icon: const Icon(Icons.close), onPressed: () => Navigator.pop(ctx))]),
              const SizedBox(height: 24),
              TextField(controller: nameController, decoration: InputDecoration(labelText: 'Name', filled: true, fillColor: Color(0xFFf4f4ef), border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none))),
              const SizedBox(height: 16),
              TextField(controller: emailController, keyboardType: TextInputType.emailAddress, decoration: InputDecoration(labelText: 'Email', filled: true, fillColor: Color(0xFFf4f4ef), border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none))),
              const SizedBox(height: 16),
              TextField(controller: passwordController, obscureText: true, decoration: InputDecoration(labelText: 'Password', filled: true, fillColor: Color(0xFFf4f4ef), border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none))),
              const SizedBox(height: 16),
              DropdownButtonFormField(
                value: selectedRole,
                decoration: InputDecoration(labelText: 'Role', filled: true, fillColor: Color(0xFFf4f4ef), border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none)),
                items: _getAvailableRoles(userRole),
                onChanged: canEdit ? (value) {
                  final newRole = (value as String?) ?? 'Shepherd';
                  setSheetState(() {
                    selectedRole = newRole;
                    if (newRole == 'Admin' || newRole == 'Owner') selectedOwnerId = null;
                  });
                } : null,
              ),
              if (userRole == 'Admin' && owners.isNotEmpty && selectedRole != 'Admin' && selectedRole != 'Owner') ...[
                const SizedBox(height: 16),
                DropdownButtonFormField(
                  value: selectedOwnerId,
                  decoration: InputDecoration(labelText: 'Assign to Owner', filled: true, fillColor: Color(0xFFf4f4ef), border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none)),
                  items: owners.map((o) => DropdownMenuItem(value: o['id'] as int, child: Text(o['name'] ?? ''))).toList(),
                  onChanged: canEdit ? (value) => setSheetState(() => selectedOwnerId = value as int?) : null,
                ),
              ],
              const SizedBox(height: 24),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: canEdit ? () async {
                    if (nameController.text.isEmpty || emailController.text.isEmpty) {
                      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Name and email are required')));
                      return;
                    }
                    try {
                      final ownerId = auth.user?['id'] as int?;
                      final managedBy = userRole == 'Owner' ? ownerId : selectedOwnerId;
                      await ApiService.createUser({'name': nameController.text, 'email': emailController.text, 'role': selectedRole, 'password': passwordController.text, 'managed_by': managedBy});
                      if (ctx.mounted) Navigator.pop(ctx);
                      if (context.mounted) {
                        context.read<DataProvider>().loadUsers();
                        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Team member added!')));
                      }
                    } catch (e) {
                      if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error: $e')));
                    }
                  } : null,
                  style: ElevatedButton.styleFrom(backgroundColor: canEdit ? Color(0xFF06402B) : Colors.grey, foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(vertical: 16), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
                  child: Text(canEdit ? 'Send Invitation' : 'Access Denied'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
