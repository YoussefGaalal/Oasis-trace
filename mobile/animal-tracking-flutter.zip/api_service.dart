import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class ApiService {
  static const String baseUrl = 'http://localhost:8050/api';

  static String? _token;
  static int? _userId;
  static String? _userRole;

  static Future<void> setToken(String token) async {
    _token = token;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('auth_token', token);
  }

  static Future<void> setUserInfo(int userId, String role) async {
    _userId = userId;
    _userRole = role;
  }

  static Future<void> loadToken() async {
    final prefs = await SharedPreferences.getInstance();
    _token = prefs.getString('auth_token');
  }

  static Future<void> clearToken() async {
    _token = null;
    _userId = null;
    _userRole = null;
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('auth_token');
  }

  static Map<String, String> get _headers => {
    'Content-Type': 'application/json',
    if (_token != null) 'Authorization': 'Bearer $_token',
    if (_userId != null) 'X-User-Id': _userId.toString(),
    if (_userRole != null) 'X-User-Role': _userRole!,
  };

  static Map<String, String> get headers => _headers;

  static Future<Map<String, dynamic>> login(
    String email,
    String password,
  ) async {
    print('Attempting login to: $baseUrl/auth/login');
    final res = await http.post(
      Uri.parse('$baseUrl/auth/login'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'email': email, 'password': password}),
    );

    print('Login response status: ${res.statusCode}');
    print('Login response body: ${res.body}');

    if (res.statusCode == 200) {
      final data = jsonDecode(res.body);
      if (data['token'] != null) {
        await setToken(data['token']);
        if (data['user'] != null) {
          await setUserInfo(data['user']['id'], data['user']['role']);
        }
      }
      return data;
    }
    throw Exception(jsonDecode(res.body)['message'] ?? 'Login failed');
  }

  static Future<void> logout() async {
    final res = await http.post(
      Uri.parse('$baseUrl/auth/logout'),
      headers: _headers,
    );
    await clearToken();
    if (res.statusCode != 200) {
      throw Exception('Logout failed');
    }
  }

  static Future<Map<String, dynamic>> fetchCurrentUser() async {
    final res = await http.get(
      Uri.parse('$baseUrl/auth/me'),
      headers: _headers,
    );
    if (res.statusCode == 200) {
      final data = jsonDecode(res.body);
      if (data['data'] != null) {
        return data['data'];
      }
      return data;
    }
    throw Exception('Failed to fetch current user');
  }

  static Future<Map<String, dynamic>> register(
    Map<String, dynamic> userData,
  ) async {
    final res = await http.post(
      Uri.parse('$baseUrl/auth/register'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode(userData),
    );

    if (res.statusCode == 201) {
      final data = jsonDecode(res.body);
      if (data['token'] != null) {
        await setToken(data['token']);
      }
      return data;
    }
    throw Exception(jsonDecode(res.body)['message'] ?? 'Registration failed');
  }

  static Future<Map<String, dynamic>> getDashboard() async {
    final res = await http.get(
      Uri.parse('$baseUrl/dashboard'),
      headers: _headers,
    );
    if (res.statusCode == 200) {
      return jsonDecode(res.body);
    }
    throw Exception('Failed to load dashboard');
  }

  static Future<List<dynamic>> getAnimals({int page = 1}) async {
    final res = await http.get(
      Uri.parse('$baseUrl/animals?page=$page&per_page=50'),
      headers: _headers,
    );
    if (res.statusCode == 200) {
      final data = jsonDecode(res.body);
      if (data is Map) {
        if (data['data'] != null) {
          return List<dynamic>.from(data['data']);
        }
        return [data];
      }
      return List<dynamic>.from(data);
    }
    throw Exception('Failed to load animals');
  }

  static Future<Map<String, dynamic>> getAnimal(int id) async {
    final res = await http.get(
      Uri.parse('$baseUrl/animals/$id'),
      headers: _headers,
    );
    if (res.statusCode == 200) {
      return jsonDecode(res.body)['data'] ?? jsonDecode(res.body);
    }
    throw Exception('Failed to load animal');
  }

  static Future<Map<String, dynamic>> createAnimal(
    Map<String, dynamic> animalData,
  ) async {
    print('API: Creating animal with data: $animalData');
    final res = await http.post(
      Uri.parse('$baseUrl/animals'),
      headers: _headers,
      body: jsonEncode(animalData),
    );
    print('API: Response status: ${res.statusCode}');
    print('API: Response body: ${res.body}');
    if (res.statusCode == 201) {
      return jsonDecode(res.body)['data'] ?? jsonDecode(res.body);
    }
    final errorBody = jsonDecode(res.body);
    throw Exception(
      errorBody['message'] ?? errorBody['error'] ?? 'Failed to create animal',
    );
  }

  static Future<Map<String, dynamic>> updateAnimal(
    int id,
    Map<String, dynamic> animalData,
  ) async {
    final res = await http.put(
      Uri.parse('$baseUrl/animals/$id'),
      headers: _headers,
      body: jsonEncode(animalData),
    );
    if (res.statusCode == 200) {
      return jsonDecode(res.body)['data'] ?? jsonDecode(res.body);
    }
    throw Exception('Failed to update animal');
  }

  static Future<void> deleteAnimal(int id) async {
    final res = await http.delete(
      Uri.parse('$baseUrl/animals/$id'),
      headers: _headers,
    );
    if (res.statusCode != 200) {
      throw Exception('Failed to delete animal');
    }
  }

  static Future<Map<String, dynamic>> getMapData() async {
    final res = await http.get(Uri.parse('$baseUrl/map'), headers: _headers);
    print('Map API response: ${res.statusCode} - ${res.body}');
    if (res.statusCode == 200) {
      return jsonDecode(res.body);
    }
    throw Exception('Failed to load map data');
  }

  static Future<List<dynamic>> getLocationHistory(int animalId) async {
    final res = await http.get(
      Uri.parse('$baseUrl/animals/$animalId/location-history'),
      headers: _headers,
    );
    if (res.statusCode == 200) {
      return jsonDecode(res.body)['data'] ?? jsonDecode(res.body);
    }
    throw Exception('Failed to load location history');
  }

  static Future<List<dynamic>> getGeofences() async {
    final res = await http.get(
      Uri.parse('$baseUrl/geofences'),
      headers: _headers,
    );
    if (res.statusCode == 200) {
      return jsonDecode(res.body)['data'] ?? jsonDecode(res.body);
    }
    throw Exception('Failed to load geofences');
  }

  static Future<List<dynamic>> getGeofenceAlerts() async {
    final res = await http.get(
      Uri.parse('$baseUrl/geofence-alerts'),
      headers: _headers,
    );
    if (res.statusCode == 200) {
      return jsonDecode(res.body)['data'] ?? jsonDecode(res.body);
    }
    throw Exception('Failed to load alerts');
  }

  static Future<void> acknowledgeAlert(int alertId) async {
    final res = await http.patch(
      Uri.parse('$baseUrl/geofence-alerts/$alertId/acknowledge'),
      headers: _headers,
    );
    if (res.statusCode != 200) {
      throw Exception('Failed to acknowledge alert');
    }
  }

  static Future<Map<String, dynamic>> createGeofence({
    required String name,
    required String coordinates,
    String? color,
    String? alertType,
  }) async {
    final res = await http.post(
      Uri.parse('$baseUrl/geofences'),
      headers: _headers,
      body: jsonEncode({
        'name': name,
        'coordinates': coordinates,
        'color': color ?? '#06402B',
        'alert_type': alertType ?? 'both',
      }),
    );
    if (res.statusCode == 201) {
      return jsonDecode(res.body);
    }
    throw Exception('Failed to create geofence');
  }

  static Future<Map<String, dynamic>> updateGeofence(
    int id,
    Map<String, dynamic> data,
  ) async {
    final res = await http.put(
      Uri.parse('$baseUrl/geofences/$id'),
      headers: _headers,
      body: jsonEncode(data),
    );
    if (res.statusCode == 200) {
      return jsonDecode(res.body);
    }
    throw Exception('Failed to update geofence');
  }

  static Future<void> deleteGeofence(int id) async {
    final res = await http.delete(
      Uri.parse('$baseUrl/geofences/$id'),
      headers: _headers,
    );
    if (res.statusCode != 200) {
      throw Exception('Failed to delete geofence');
    }
  }

  static Future<List<dynamic>> getAnimalGroups() async {
    final res = await http.get(
      Uri.parse('$baseUrl/animal-groups'),
      headers: _headers,
    );
    if (res.statusCode == 200) {
      return jsonDecode(res.body)['data'] ?? jsonDecode(res.body);
    }
    throw Exception('Failed to load animal groups');
  }

  static Future<Map<String, dynamic>> getReports() async {
    final res = await http.get(
      Uri.parse('$baseUrl/reports'),
      headers: _headers,
    );
    if (res.statusCode == 200) {
      return jsonDecode(res.body);
    }
    throw Exception('Failed to load reports');
  }

  // Device endpoints
  static Future<List<dynamic>> getDevices() async {
    final res = await http.get(
      Uri.parse('$baseUrl/devices'),
      headers: _headers,
    );
    if (res.statusCode == 200) {
      return jsonDecode(res.body)['data'] ?? jsonDecode(res.body);
    }
    throw Exception('Failed to load devices');
  }

  static Future<Map<String, dynamic>> createDevice(
    Map<String, dynamic> deviceData,
  ) async {
    final res = await http.post(
      Uri.parse('$baseUrl/devices'),
      headers: _headers,
      body: jsonEncode(deviceData),
    );
    if (res.statusCode == 201) {
      return jsonDecode(res.body);
    }
    throw Exception('Failed to create device');
  }

  static Future<Map<String, dynamic>> updateDevice(
    int id,
    Map<String, dynamic> deviceData,
  ) async {
    final res = await http.put(
      Uri.parse('$baseUrl/devices/$id'),
      headers: _headers,
      body: jsonEncode(deviceData),
    );
    if (res.statusCode == 200) {
      return jsonDecode(res.body);
    }
    throw Exception('Failed to update device');
  }

  static Future<void> deleteDevice(int id) async {
    final res = await http.delete(
      Uri.parse('$baseUrl/devices/$id'),
      headers: _headers,
    );
    if (res.statusCode != 200) {
      throw Exception('Failed to delete device');
    }
  }

  // User/Team endpoints
  static Future<List<dynamic>> getUsers() async {
    final res = await http.get(Uri.parse('$baseUrl/users'), headers: _headers);
    if (res.statusCode == 200) {
      return jsonDecode(res.body)['data'] ?? jsonDecode(res.body);
    }
    throw Exception('Failed to load users');
  }

  static Future<Map<String, dynamic>> createUser(
    Map<String, dynamic> userData,
  ) async {
    final res = await http.post(
      Uri.parse('$baseUrl/users'),
      headers: _headers,
      body: jsonEncode(userData),
    );
    if (res.statusCode == 201) {
      return jsonDecode(res.body);
    }
    throw Exception('Failed to create user');
  }

  static Future<Map<String, dynamic>> updateUser(
    int id,
    Map<String, dynamic> userData,
  ) async {
    final res = await http.put(
      Uri.parse('$baseUrl/users/$id'),
      headers: _headers,
      body: jsonEncode(userData),
    );
    if (res.statusCode == 200) {
      return jsonDecode(res.body);
    }
    throw Exception('Failed to update user');
  }

  static Future<void> deleteUser(int id) async {
    final res = await http.delete(
      Uri.parse('$baseUrl/users/$id'),
      headers: _headers,
    );
    if (res.statusCode != 200) {
      throw Exception('Failed to delete user');
    }
  }

  static Future<Map<String, dynamic>> toggleUserStatus(int id) async {
    final res = await http.patch(
      Uri.parse('$baseUrl/users/$id/toggle-status'),
      headers: _headers,
    );
    if (res.statusCode == 200) {
      return jsonDecode(res.body);
    }
    throw Exception('Failed to toggle user status');
  }

  // Task endpoints
  static Future<List<dynamic>> getTasks() async {
    final res = await http.get(Uri.parse('$baseUrl/tasks'), headers: _headers);
    if (res.statusCode == 200) {
      return jsonDecode(res.body)['data'] ?? jsonDecode(res.body);
    }
    throw Exception('Failed to load tasks');
  }

  static Future<List<dynamic>> getMyTasks() async {
    final res = await http.get(
      Uri.parse('$baseUrl/tasks/my'),
      headers: _headers,
    );
    if (res.statusCode == 200) {
      return jsonDecode(res.body)['data'] ?? jsonDecode(res.body);
    }
    throw Exception('Failed to load my tasks');
  }

  static Future<Map<String, dynamic>> createTask(
    Map<String, dynamic> taskData,
  ) async {
    final res = await http.post(
      Uri.parse('$baseUrl/tasks'),
      headers: _headers,
      body: jsonEncode(taskData),
    );
    if (res.statusCode == 201) {
      return jsonDecode(res.body);
    }
    throw Exception('Failed to create task');
  }

  static Future<Map<String, dynamic>> updateTask(
    int id,
    Map<String, dynamic> taskData,
  ) async {
    final res = await http.put(
      Uri.parse('$baseUrl/tasks/$id'),
      headers: _headers,
      body: jsonEncode(taskData),
    );
    if (res.statusCode == 200) {
      return jsonDecode(res.body);
    }
    throw Exception('Failed to update task');
  }

  static Future<void> completeTask(int id) async {
    final res = await http.post(
      Uri.parse('$baseUrl/tasks/$id/complete'),
      headers: _headers,
    );
    if (res.statusCode != 200) {
      throw Exception('Failed to complete task');
    }
  }

  static Future<void> deleteTask(int id) async {
    final res = await http.delete(
      Uri.parse('$baseUrl/tasks/$id'),
      headers: _headers,
    );
    if (res.statusCode != 200) {
      throw Exception('Failed to delete task');
    }
  }

  // Auction endpoints
  static Future<List<dynamic>> getAuctions() async {
    final res = await http.get(
      Uri.parse('$baseUrl/auctions'),
      headers: _headers,
    );
    if (res.statusCode == 200) {
      return jsonDecode(res.body)['data'] ?? jsonDecode(res.body);
    }
    throw Exception('Failed to load auctions');
  }

  static Future<List<dynamic>> getMyAuctions() async {
    final res = await http.get(
      Uri.parse('$baseUrl/auctions/my'),
      headers: _headers,
    );
    if (res.statusCode == 200) {
      return jsonDecode(res.body)['data'] ?? jsonDecode(res.body);
    }
    throw Exception('Failed to load my auctions');
  }

  static Future<List<dynamic>> getMyBids() async {
    final res = await http.get(
      Uri.parse('$baseUrl/auctions/my-bids'),
      headers: _headers,
    );
    if (res.statusCode == 200) {
      return jsonDecode(res.body)['data'] ?? jsonDecode(res.body);
    }
    throw Exception('Failed to load my bids');
  }

  static Future<Map<String, dynamic>> getAuction(int id) async {
    final res = await http.get(
      Uri.parse('$baseUrl/auctions/$id'),
      headers: _headers,
    );
    if (res.statusCode == 200) {
      return jsonDecode(res.body)['data'] ?? jsonDecode(res.body);
    }
    throw Exception('Failed to load auction');
  }

  static Future<Map<String, dynamic>> createAuction(
    Map<String, dynamic> auctionData,
  ) async {
    final res = await http.post(
      Uri.parse('$baseUrl/auctions'),
      headers: _headers,
      body: jsonEncode(auctionData),
    );
    if (res.statusCode == 201) {
      return jsonDecode(res.body);
    }
    throw Exception('Failed to create auction');
  }

  static Future<Map<String, dynamic>> placeBid(
    int auctionId,
    double amount,
  ) async {
    final res = await http.post(
      Uri.parse('$baseUrl/auctions/$auctionId/bid'),
      headers: _headers,
      body: jsonEncode({'amount': amount}),
    );
    if (res.statusCode == 200) {
      return jsonDecode(res.body);
    }
    throw Exception('Failed to place bid');
  }

  static Future<void> cancelAuction(int id) async {
    final res = await http.post(
      Uri.parse('$baseUrl/auctions/$id/cancel'),
      headers: _headers,
    );
    if (res.statusCode != 200) {
      throw Exception('Failed to cancel auction');
    }
  }

  static Future<Map<String, dynamic>> createAnimalGroup(
    Map<String, dynamic> groupData,
  ) async {
    final res = await http.post(
      Uri.parse('$baseUrl/animal-groups'),
      headers: _headers,
      body: jsonEncode(groupData),
    );
    if (res.statusCode == 201) {
      return jsonDecode(res.body);
    }
    throw Exception('Failed to create animal group');
  }

  // Geofence endpoints - additional
  static Future<List<dynamic>> getGeofenceAnimals(int geofenceId) async {
    final res = await http.get(
      Uri.parse('$baseUrl/geofences/$geofenceId/animals'),
      headers: _headers,
    );
    if (res.statusCode == 200) {
      return jsonDecode(res.body)['data'] ?? jsonDecode(res.body);
    }
    throw Exception('Failed to load geofence animals');
  }

  static Future<void> assignAnimalsToGeofence(
    int geofenceId,
    List<int> animalIds,
  ) async {
    final res = await http.post(
      Uri.parse('$baseUrl/geofences/$geofenceId/animals'),
      headers: _headers,
      body: jsonEncode({'animal_ids': animalIds}),
    );
    if (res.statusCode != 200) {
      throw Exception('Failed to assign animals');
    }
  }

  // Subscription endpoints
  static Future<List<dynamic>> getSubscriptionTiers() async {
    final res = await http.get(
      Uri.parse('$baseUrl/subscription/tiers'),
      headers: _headers,
    );
    if (res.statusCode == 200) {
      return jsonDecode(res.body)['data'] ?? jsonDecode(res.body);
    }
    throw Exception('Failed to load subscription tiers');
  }

  static Future<Map<String, dynamic>> getCurrentSubscription() async {
    final res = await http.get(
      Uri.parse('$baseUrl/subscription/current'),
      headers: _headers,
    );
    if (res.statusCode == 200) {
      return jsonDecode(res.body);
    }
    throw Exception('Failed to load current subscription');
  }

  static Future<Map<String, dynamic>> subscribeToTier(String tierId) async {
    final res = await http.post(
      Uri.parse('$baseUrl/subscription/subscribe/$tierId'),
      headers: _headers,
    );
    if (res.statusCode == 200) {
      return jsonDecode(res.body);
    }
    throw Exception('Failed to subscribe');
  }

  // Vaccination endpoints
  static Future<List<dynamic>> getVaccinations() async {
    final res = await http.get(
      Uri.parse('$baseUrl/vaccinations'),
      headers: _headers,
    );
    if (res.statusCode == 200) {
      return jsonDecode(res.body)['data'] ?? jsonDecode(res.body);
    }
    throw Exception('Failed to load vaccinations');
  }

  static Future<Map<String, dynamic>> createVaccination(
    Map<String, dynamic> data,
  ) async {
    final res = await http.post(
      Uri.parse('$baseUrl/vaccinations'),
      headers: _headers,
      body: jsonEncode(data),
    );
    if (res.statusCode == 201) {
      return jsonDecode(res.body);
    }
    throw Exception('Failed to create vaccination');
  }

  static Future<Map<String, dynamic>> updateVaccination(
    int id,
    Map<String, dynamic> data,
  ) async {
    final res = await http.put(
      Uri.parse('$baseUrl/vaccinations/$id'),
      headers: _headers,
      body: jsonEncode(data),
    );
    if (res.statusCode == 200) {
      return jsonDecode(res.body);
    }
    throw Exception('Failed to update vaccination');
  }

  static Future<void> markVaccinationAdministered(int id) async {
    final res = await http.patch(
      Uri.parse('$baseUrl/vaccinations/$id/administer'),
      headers: _headers,
    );
    if (res.statusCode != 200) {
      throw Exception('Failed to mark vaccination as administered');
    }
  }

  // Medical Records endpoints
  static Future<List<dynamic>> getMedicalRecords() async {
    final res = await http.get(
      Uri.parse('$baseUrl/medical-records'),
      headers: _headers,
    );
    if (res.statusCode == 200) {
      return jsonDecode(res.body)['data'] ?? jsonDecode(res.body);
    }
    throw Exception('Failed to load medical records');
  }

  static Future<Map<String, dynamic>> createMedicalRecord(
    Map<String, dynamic> data,
  ) async {
    final res = await http.post(
      Uri.parse('$baseUrl/medical-records'),
      headers: _headers,
      body: jsonEncode(data),
    );
    if (res.statusCode == 201) {
      return jsonDecode(res.body);
    }
    throw Exception('Failed to create medical record');
  }
}
