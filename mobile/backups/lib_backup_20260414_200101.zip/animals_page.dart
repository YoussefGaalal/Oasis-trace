import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'data_provider.dart';
import 'auth_provider.dart';
import 'navigation.dart';
import 'unified_header.dart';

class AnimalsPage extends StatefulWidget {
  @override
  State<AnimalsPage> createState() => _AnimalsPageState();
}

class _AnimalsPageState extends State<AnimalsPage> {
  int _selectedNav = 2;
  String _searchQuery = '';
  String _filterSpecies = 'All';
  String _sortBy = 'name';
  final ScrollController _scrollController = ScrollController();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<DataProvider>().loadAnimals();
    });
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final authProvider = context.read<AuthProvider>();
    final user = authProvider.user;
    final role = user?['role'] ?? 'user';
    final canEdit = role == 'admin' || role == 'manager';

    return Scaffold(
      backgroundColor: const Color(0xFFfafaf5),
      body: Column(
        children: [
          UnifiedHeader(
            title: 'Animals',
            showBackButton: true,
            onBack: () => Navigator.pop(context),
            actions: [
              PopupMenuButton(
                icon: const Icon(Icons.sort, color: Color(0xFF06402B)),
                onSelected: (value) {
                  setState(() {
                    _sortBy = value;
                  });
                },
                itemBuilder: (context) => [
                  const PopupMenuItem(
                    value: 'name',
                    child: Text('Sort by Name'),
                  ),
                  const PopupMenuItem(
                    value: 'animal_id',
                    child: Text('Sort by ID'),
                  ),
                  const PopupMenuItem(
                    value: 'species',
                    child: Text('Sort by Species'),
                  ),
                ],
              ),
              if (canEdit)
                GestureDetector(
                  onTap: () => _showAddAnimalModal(context),
                  child: Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: const Color(0xFF06402B),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: const Icon(Icons.add, color: Colors.white, size: 20),
                  ),
                ),
            ],
          ),
          Expanded(
            child: CustomScrollView(
              controller: _scrollController,
              slivers: [
                SliverPadding(
                  padding: const EdgeInsets.all(16),
                  sliver: SliverToBoxAdapter(
                    child: TextField(
                      onChanged: (v) => setState(() => _searchQuery = v),
                      decoration: InputDecoration(
                        hintText: 'Search animals...',
                        prefixIcon: const Icon(Icons.search),
                        filled: true,
                        fillColor: Colors.white,
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: BorderSide.none,
                        ),
                      ),
                    ),
                  ),
                ),
                SliverPadding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  sliver: SliverToBoxAdapter(
                    child: Container(
                      height: 40,
                      child: ListView(
                        scrollDirection: Axis.horizontal,
                        children: [
                          _buildFilterChip('All'),
                          const SizedBox(width: 8),
                          _buildFilterChip('Cattle'),
                          const SizedBox(width: 8),
                          _buildFilterChip('Sheep'),
                          const SizedBox(width: 8),
                          _buildFilterChip('Goat'),
                          const SizedBox(width: 8),
                          _buildFilterChip('Horse'),
                        ],
                      ),
                    ),
                  ),
                ),
                Consumer<DataProvider>(
                  builder: (context, dataProvider, child) {
                    var animals = dataProvider.animals;

                    if (animals.isEmpty) {
                      return const SliverFillRemaining(
                        child: Center(child: Text('No animals found')),
                      );
                    }

                    if (_searchQuery.isNotEmpty) {
                      animals = animals.where((a) {
                        final name = (a['name'] ?? '').toString().toLowerCase();
                        final id = (a['animal_id'] ?? '')
                            .toString()
                            .toLowerCase();
                        return name.contains(_searchQuery.toLowerCase()) ||
                            id.contains(_searchQuery.toLowerCase());
                      }).toList();
                    }

                    if (_filterSpecies != 'All') {
                      animals = animals.where((a) {
                        return a['species'] == _filterSpecies;
                      }).toList();
                    }

                    if (_sortBy == 'name') {
                      animals.sort(
                        (a, b) => (a['name'] ?? '').toString().compareTo(
                          b['name'] ?? '',
                        ),
                      );
                    } else if (_sortBy == 'animal_id') {
                      animals.sort(
                        (a, b) => (a['animal_id'] ?? '').toString().compareTo(
                          b['animal_id'] ?? '',
                        ),
                      );
                    } else if (_sortBy == 'species') {
                      animals.sort(
                        (a, b) => (a['species'] ?? '').toString().compareTo(
                          b['species'] ?? '',
                        ),
                      );
                    }

                    return SliverList(
                      delegate: SliverChildBuilderDelegate((context, index) {
                        final animal = animals[index];
                        return _buildAnimalCard(context, animal, canEdit);
                      }, childCount: animals.length),
                    );
                  },
                ),
                const SliverToBoxAdapter(child: SizedBox(height: 100)),
              ],
            ),
          ),
          const SizedBox(height: 80),
        ],
      ),
      bottomNavigationBar: UnifiedBottomNav(
        currentIndex: 2,
        onTap: (index) {
          final pages = ['Dashboard', 'Map', 'Animals', 'Alerts', 'Profile'];
          PageNavigator.navigateToPage(context, pages[index]);
        },
      ),
    );
  }

  Widget _buildFilterChip(String species) {
    final isSelected = _filterSpecies == species;
    return GestureDetector(
      onTap: () => setState(() => _filterSpecies = species),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        decoration: BoxDecoration(
          color: isSelected ? const Color(0xFF06402B) : Colors.white,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: isSelected ? const Color(0xFF06402B) : const Color(0xFFddd),
          ),
        ),
        child: Text(
          species,
          style: TextStyle(
            color: isSelected ? Colors.white : const Color(0xFF06402B),
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
    );
  }

  Widget _buildAnimalCard(
    BuildContext context,
    Map<String, dynamic> animal,
    bool canEdit,
  ) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: ListTile(
        onTap: () => _showAnimalDetails(context, animal, canEdit),
        contentPadding: const EdgeInsets.all(16),
        leading: CircleAvatar(
          radius: 30,
          backgroundColor: const Color(0xFFf4f4ef),
          backgroundImage: animal['photo_url'] != null
              ? NetworkImage(animal['photo_url'])
              : null,
          child: animal['photo_url'] == null
              ? const Icon(Icons.pets, color: Color(0xFF06402B))
              : null,
        ),
        title: Text(
          animal['name'] ?? animal['animal_id'] ?? 'Unknown',
          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
        ),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 4),
            Text(
              'ID: ${animal['animal_id'] ?? 'N/A'}',
              style: const TextStyle(color: Color(0xFF717973), fontSize: 12),
            ),
            Text(
              '${animal['species'] ?? 'N/A'} - ${animal['breed'] ?? 'N/A'}',
              style: const TextStyle(color: Color(0xFF717973), fontSize: 12),
            ),
          ],
        ),
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              decoration: BoxDecoration(
                color: animal['status'] == 'active'
                    ? const Color(0xFF22c55e).withOpacity(0.1)
                    : const Color(0xFFef4444).withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Text(
                animal['status'] == 'active' ? 'Active' : 'Inactive',
                style: TextStyle(
                  color: animal['status'] == 'active'
                      ? const Color(0xFF22c55e)
                      : const Color(0xFFef4444),
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
            if (canEdit)
              IconButton(
                icon: const Icon(Icons.edit, color: Color(0xFFfbbf24)),
                onPressed: () => _showEditAnimalModal(context, animal),
              ),
          ],
        ),
      ),
    );
  }

  void _showAnimalDetails(
    BuildContext context,
    Map<String, dynamic> animal,
    bool canEdit,
  ) {
    final ctx = context;
    showModalBottomSheet(
      context: ctx,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => Container(
        height: MediaQuery.of(ctx).size.height * 0.7,
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
        ),
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    animal['name'] ?? animal['animal_id'] ?? 'Unknown',
                    style: const TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.close),
                    onPressed: () => Navigator.pop(ctx),
                  ),
                ],
              ),
            ),
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    Container(
                      width: 100,
                      height: 100,
                      decoration: BoxDecoration(
                        color: const Color(0xFFf4f4ef),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: animal['photo_url'] != null
                          ? ClipRRect(
                              borderRadius: BorderRadius.circular(20),
                              child: Image.network(
                                animal['photo_url'],
                                fit: BoxFit.cover,
                              ),
                            )
                          : const Icon(
                              Icons.pets,
                              size: 40,
                              color: Color(0xFF06402B),
                            ),
                    ),
                    const SizedBox(height: 24),
                    _detailRow('Animal ID', animal['animal_id'] ?? 'N/A'),
                    _detailRow('Species', animal['species'] ?? 'N/A'),
                    _detailRow('Breed', animal['breed'] ?? 'N/A'),
                    _detailRow('Gender', animal['gender'] ?? 'N/A'),
                    _detailRow(
                      'Color/Markings',
                      animal['color_markings'] ?? 'N/A',
                    ),
                    _detailRow(
                      'Date of Birth',
                      animal['date_of_birth'] ?? 'N/A',
                    ),
                    _detailRow('Weight', '${animal['weight'] ?? 0} kg'),
                    _detailRow('Status', animal['status'] ?? 'N/A'),
                    _detailRow('Location', animal['location'] ?? 'N/A'),
                    _detailRow(
                      'Normal Heart Rate',
                      '${animal['normal_heart_rate'] ?? 0} BPM',
                    ),
                    _detailRow('Device ID', animal['device_id'] ?? 'N/A'),
                    const SizedBox(height: 24),
                    Row(
                      children: [
                        Expanded(
                          child: ElevatedButton.icon(
                            onPressed: () {
                              Navigator.pop(ctx);
                              PageNavigator.navigateToPage(ctx, 'Map');
                            },
                            icon: const Icon(Icons.map),
                            label: const Text('View Map'),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: const Color(0xFF06402B),
                              foregroundColor: Colors.white,
                              padding: const EdgeInsets.all(14),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12),
                              ),
                            ),
                          ),
                        ),
                        if (canEdit) ...[
                          const SizedBox(width: 12),
                          IconButton(
                            icon: const Icon(
                              Icons.edit,
                              color: Color(0xFFfbbf24),
                            ),
                            onPressed: () {
                              Navigator.pop(ctx);
                              _showEditAnimalModal(ctx, animal);
                            },
                          ),
                        ],
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _detailRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: const TextStyle(color: Color(0xFF717973))),
          Text(value, style: const TextStyle(fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }

  void _showAddAnimalModal(BuildContext context) {
    final ctx = context;
    final formKey = GlobalKey<FormState>();
    final nameController = TextEditingController();
    final tagIdController = TextEditingController();
    final colorController = TextEditingController();
    final selectedSpecies = 'Cattle';

    final speciesOptions = ['Cattle', 'Sheep', 'Goat', 'Horse', 'Other'];
    final breedOptions = [
      'Angus',
      'Hereford',
      'Brahman',
      'Charolais',
      'Simmental',
    ];
    final genderOptions = ['Male', 'Female'];

    String selectedBreed = 'Angus';
    String selectedGender = 'Male';

    showModalBottomSheet(
      context: ctx,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setModalState) => Container(
          height: MediaQuery.of(ctx).size.height * 0.85,
          decoration: const BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
          ),
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(16),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text(
                      'Add Animal',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.close),
                      onPressed: () => Navigator.pop(ctx),
                    ),
                  ],
                ),
              ),
              Expanded(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.all(16),
                  child: Form(
                    key: formKey,
                    child: Column(
                      children: [
                        TextFormField(
                          controller: nameController,
                          decoration: InputDecoration(
                            labelText: 'Name',
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                          ),
                          validator: (v) =>
                              v?.isEmpty ?? true ? 'Required' : null,
                        ),
                        const SizedBox(height: 16),
                        TextFormField(
                          controller: tagIdController,
                          decoration: InputDecoration(
                            labelText: 'Tag ID (optional)',
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                          ),
                        ),
                        const SizedBox(height: 16),
                        DropdownButtonFormField(
                          value: selectedSpecies,
                          decoration: InputDecoration(
                            labelText: 'Species',
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                          ),
                          items: speciesOptions
                              .map(
                                (s) =>
                                    DropdownMenuItem(value: s, child: Text(s)),
                              )
                              .toList(),
                          onChanged: (v) {},
                        ),
                        const SizedBox(height: 16),
                        DropdownButtonFormField(
                          value: selectedBreed,
                          decoration: InputDecoration(
                            labelText: 'Breed',
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                          ),
                          items: breedOptions
                              .map(
                                (b) =>
                                    DropdownMenuItem(value: b, child: Text(b)),
                              )
                              .toList(),
                          onChanged: (v) {},
                        ),
                        const SizedBox(height: 16),
                        DropdownButtonFormField(
                          value: selectedGender,
                          decoration: InputDecoration(
                            labelText: 'Gender',
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                          ),
                          items: genderOptions
                              .map(
                                (g) =>
                                    DropdownMenuItem(value: g, child: Text(g)),
                              )
                              .toList(),
                          onChanged: (v) {},
                        ),
                        const SizedBox(height: 16),
                        TextFormField(
                          controller: colorController,
                          decoration: InputDecoration(
                            labelText: 'Color/Markings',
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                          ),
                        ),
                        const SizedBox(height: 24),
                        SizedBox(
                          width: double.infinity,
                          height: 56,
                          child: ElevatedButton(
                            onPressed: () async {
                              if (formKey.currentState!.validate()) {
                                try {
                                  final dataProvider = context
                                      .read<DataProvider>();

                                  final animalData = {
                                    'name': nameController.text,
                                    'animal_id': tagIdController.text.isNotEmpty
                                        ? tagIdController.text
                                        : 'OA-${DateTime.now().year}-${DateTime.now().millisecondsSinceEpoch}',
                                    'species': selectedSpecies,
                                    'breed': selectedBreed,
                                    'gender': selectedGender,
                                    'color_markings':
                                        colorController.text.isNotEmpty
                                        ? colorController.text
                                        : 'N/A',
                                    'status': 'active',
                                  };

                                  print('Creating animal: $animalData');

                                  await dataProvider.createAnimal(animalData);

                                  Navigator.pop(ctx);

                                  ScaffoldMessenger.of(context).showSnackBar(
                                    const SnackBar(
                                      content: Text(
                                        'Animal added successfully!',
                                      ),
                                      backgroundColor: Color(0xFF0B5D3B),
                                    ),
                                  );
                                } catch (e) {
                                  print('Error: $e');
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    SnackBar(
                                      content: Text('Error: $e'),
                                      backgroundColor: const Color(0xFFba1a1a),
                                    ),
                                  );
                                }
                              }
                            },
                            style: ElevatedButton.styleFrom(
                              backgroundColor: const Color(0xFF06402B),
                              foregroundColor: Colors.white,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12),
                              ),
                            ),
                            child: const Text('Add Animal'),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showEditAnimalModal(BuildContext context, Map<String, dynamic> animal) {
    final ctx = context;
    final formKey = GlobalKey<FormState>();
    final nameController = TextEditingController(
      text: animal['name'] ?? animal['animal_id'] ?? '',
    );
    final tagIdController = TextEditingController(
      text: animal['animal_id'] ?? '',
    );
    final colorController = TextEditingController(
      text: animal['color_markings'] ?? '',
    );

    final selectedSpecies = animal['species'] ?? 'Cattle';
    final selectedBreed = animal['breed'] ?? 'Angus';
    final selectedGender = animal['gender'] ?? 'Male';

    final speciesOptions = ['Cattle', 'Sheep', 'Goat', 'Horse', 'Other'];
    final breedOptions = [
      'Angus',
      'Hereford',
      'Brahman',
      'Charolais',
      'Simmental',
    ];
    final genderOptions = ['Male', 'Female'];

    showModalBottomSheet(
      context: ctx,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setModalState) => Container(
          height: MediaQuery.of(ctx).size.height * 0.85,
          decoration: const BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
          ),
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(16),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text(
                      'Edit Animal',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.close),
                      onPressed: () => Navigator.pop(ctx),
                    ),
                  ],
                ),
              ),
              Expanded(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.all(16),
                  child: Form(
                    key: formKey,
                    child: Column(
                      children: [
                        TextFormField(
                          controller: nameController,
                          decoration: InputDecoration(
                            labelText: 'Name',
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                          ),
                          validator: (v) =>
                              v?.isEmpty ?? true ? 'Required' : null,
                        ),
                        const SizedBox(height: 16),
                        TextFormField(
                          controller: tagIdController,
                          decoration: InputDecoration(
                            labelText: 'Tag ID',
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                          ),
                          validator: (v) =>
                              v?.isEmpty ?? true ? 'Required' : null,
                        ),
                        const SizedBox(height: 16),
                        DropdownButtonFormField(
                          value: selectedSpecies,
                          decoration: InputDecoration(
                            labelText: 'Species',
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                          ),
                          items: speciesOptions
                              .map(
                                (s) =>
                                    DropdownMenuItem(value: s, child: Text(s)),
                              )
                              .toList(),
                          onChanged: (v) {},
                        ),
                        const SizedBox(height: 16),
                        DropdownButtonFormField(
                          value: selectedBreed,
                          decoration: InputDecoration(
                            labelText: 'Breed',
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                          ),
                          items: breedOptions
                              .map(
                                (b) =>
                                    DropdownMenuItem(value: b, child: Text(b)),
                              )
                              .toList(),
                          onChanged: (v) {},
                        ),
                        const SizedBox(height: 16),
                        DropdownButtonFormField(
                          value: selectedGender,
                          decoration: InputDecoration(
                            labelText: 'Gender',
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                          ),
                          items: genderOptions
                              .map(
                                (g) =>
                                    DropdownMenuItem(value: g, child: Text(g)),
                              )
                              .toList(),
                          onChanged: (v) {},
                        ),
                        const SizedBox(height: 16),
                        TextFormField(
                          controller: colorController,
                          decoration: InputDecoration(
                            labelText: 'Color/Markings',
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                          ),
                        ),
                        const SizedBox(height: 24),
                        SizedBox(
                          width: double.infinity,
                          height: 56,
                          child: ElevatedButton(
                            onPressed: () async {
                              if (formKey.currentState!.validate()) {
                                final dataProvider = context
                                    .read<DataProvider>();
                                await dataProvider.updateAnimal(animal['id'], {
                                  'name': nameController.text,
                                  'species': selectedSpecies,
                                  'breed': selectedBreed,
                                  'gender': selectedGender,
                                  'color_markings': colorController.text,
                                });

                                Navigator.pop(ctx);

                                ScaffoldMessenger.of(context).showSnackBar(
                                  const SnackBar(
                                    content: Text('Animal updated!'),
                                    backgroundColor: Color(0xFF0B5D3B),
                                  ),
                                );
                              }
                            },
                            style: ElevatedButton.styleFrom(
                              backgroundColor: const Color(0xFF06402B),
                              foregroundColor: Colors.white,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12),
                              ),
                            ),
                            child: const Text('Save Changes'),
                          ),
                        ),
                        const SizedBox(height: 16),
                        SizedBox(
                          width: double.infinity,
                          height: 56,
                          child: ElevatedButton(
                            onPressed: () async {
                              _showDeleteConfirmation(context, animal);
                            },
                            style: ElevatedButton.styleFrom(
                              backgroundColor: const Color(0xFFba1a1a),
                              foregroundColor: Colors.white,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12),
                              ),
                            ),
                            child: const Text('Delete Animal'),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showDeleteConfirmation(
    BuildContext context,
    Map<String, dynamic> animal,
  ) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Delete Animal'),
        content: Text(
          'Are you sure you want to delete ${animal['name'] ?? animal['animal_id'] ?? 'this animal'}?',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () async {
              final dataProvider = context.read<DataProvider>();
              await dataProvider.deleteAnimal(animal['id']);

              Navigator.pop(ctx);
              Navigator.pop(ctx);

              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('Animal deleted!'),
                  backgroundColor: Color(0xFF0B5D3B),
                ),
              );
            },
            style: TextButton.styleFrom(foregroundColor: Colors.red),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
  }
}
