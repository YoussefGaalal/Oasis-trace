import 'package:flutter/material.dart';
import 'api_service.dart';

class DataProvider extends ChangeNotifier {
  bool _isLoading = false;
  bool get isLoading => _isLoading;
  String? _error;
  String? get error => _error;

  Map<String, dynamic>? _dashboardData;
  Map<String, dynamic>? get dashboardData => _dashboardData;

  List<dynamic> _animals = [];
  List<dynamic> get animals => _animals;

  List<Map<String, dynamic>> _mapData = [];
  List<Map<String, dynamic>> get mapData => _mapData;

  List<Map<String, dynamic>> _alerts = [];
  List<Map<String, dynamic>> get alerts => _alerts;

  List<Map<String, dynamic>> _geofences = [];
  List<Map<String, dynamic>> get geofences => _geofences;

  List<Map<String, dynamic>> _devices = [];
  List<Map<String, dynamic>> get devices => _devices;

  List<Map<String, dynamic>> _tasks = [];
  List<Map<String, dynamic>> get tasks => _tasks;

  List<Map<String, dynamic>> _auctions = [];
  List<Map<String, dynamic>> get auctions => _auctions;

  List<Map<String, dynamic>> _users = [];
  List<Map<String, dynamic>> get users => _users;

  List<String> _speciesOptions = ['Camel', 'Goat', 'Sheep'];
  List<String> get speciesOptions => _speciesOptions;

  List<String> _breedOptions = [
    'Wadhah',
    'Majaheem',
    'Suhail',
    'Boer',
    'Awassi',
  ];
  List<String> get breedOptions => _breedOptions;

  List<String> _genderOptions = ['Male', 'Female'];
  List<String> get genderOptions => _genderOptions;

  Future<void> loadMasterData() async {
    try {
      final animals = await ApiService.getAnimals();
      final speciesSet = <String>{};
      final breedSet = <String>{};

      for (final animal in animals) {
        if (animal['species'] != null &&
            (animal['species'] as String).isNotEmpty) {
          speciesSet.add(animal['species'] as String);
        }
        if (animal['breed'] != null && (animal['breed'] as String).isNotEmpty) {
          breedSet.add(animal['breed'] as String);
        }
      }

      if (speciesSet.isNotEmpty) {
        _speciesOptions = speciesSet.toList()..sort();
      }
      if (breedSet.isNotEmpty) {
        _breedOptions = breedSet.toList()..sort();
      }
      notifyListeners();
    } catch (e) {
      print('Error loading master data: $e');
    }
  }

  Future<void> loadDashboard() async {
    _isLoading = true;
    _error = null;
    notifyListeners();

    try {
      _dashboardData = await ApiService.getDashboard();
      _isLoading = false;
      notifyListeners();
    } catch (e) {
      _error = e.toString();
      _isLoading = false;
      notifyListeners();
      _loadDemoData();
    }
  }

  int _animalPage = 1;
  bool _hasMoreAnimals = true;

  Future<void> loadAnimals() async {
    _isLoading = true;
    _error = null;
    _animalPage = 1;
    _hasMoreAnimals = true;
    notifyListeners();

    try {
      _animals = await ApiService.getAnimals();
      print('Animals loaded from API: ${_animals.length}');
      _hasMoreAnimals = _animals.length >= 20;
      _isLoading = false;
      notifyListeners();
    } catch (e) {
      print('Error loading animals: $e');
      _error = e.toString();
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> loadMoreAnimals() async {
    if (!_hasMoreAnimals || _isLoading) return;

    try {
      _animalPage++;
      final moreAnimals = await ApiService.getAnimals(page: _animalPage);
      if (moreAnimals.isEmpty) {
        _hasMoreAnimals = false;
      } else {
        _animals.addAll(moreAnimals);
        _hasMoreAnimals = moreAnimals.length >= 20;
      }
      notifyListeners();
    } catch (e) {
      _animalPage--;
      print('Error loading more animals: $e');
    }
  }

  Future<void> loadMapData() async {
    _isLoading = true;
    _error = null;
    notifyListeners();

    try {
      final data = await ApiService.getMapData();
      final markers = data['markers'] as List<dynamic>? ?? [];

      _mapData = [];
      for (final device in markers) {
        final d = device as Map<String, dynamic>;
        final animal = d['animal'] as Map<String, dynamic>?;
        _mapData.add({
          'id': d['id'],
          'device_id': d['device_id'],
          'name': d['name'] ?? d['device_id'],
          'status': d['status'] ?? 'online',
          'battery_level': d['battery_level'] ?? 0,
          'latitude': d['gps_lat'],
          'longitude': d['gps_lng'],
          'animal_id': animal?['id'],
          'animal_name': animal?['name'],
          'species': null,
          'breed': null,
        });
      }

      _geofences = (await ApiService.getGeofences())
          .cast<Map<String, dynamic>>();
      _isLoading = false;
      notifyListeners();
    } catch (e) {
      print('Error loading map data: $e');
      _error = e.toString();
      _isLoading = false;
      notifyListeners();
      _loadDemoMapData();
    }
  }

  Future<void> loadGeofences() async {
    try {
      _geofences = (await ApiService.getGeofences())
          .cast<Map<String, dynamic>>();
      notifyListeners();
    } catch (e) {
      _geofences = _demoGeofences.cast<Map<String, dynamic>>();
      notifyListeners();
    }
  }

  Future<void> loadAlerts() async {
    try {
      _alerts = (await ApiService.getGeofenceAlerts())
          .cast<Map<String, dynamic>>();
      notifyListeners();
    } catch (e) {
      print('Error loading alerts: $e');
      _alerts = _demoAlerts.cast<Map<String, dynamic>>();
      notifyListeners();
    }
  }

  Future<void> loadTasks() async {
    try {
      _tasks = (await ApiService.getTasks()).cast<Map<String, dynamic>>();
      notifyListeners();
    } catch (e) {
      print('Error loading tasks: $e');
      notifyListeners();
    }
  }

  Future<void> loadAuctions() async {
    try {
      _auctions = (await ApiService.getAuctions()).cast<Map<String, dynamic>>();
      notifyListeners();
    } catch (e) {
      print('Error loading auctions: $e');
      _auctions = _demoAuctions.cast<Map<String, dynamic>>();
      notifyListeners();
    }
  }

  Future<void> loadUsers() async {
    try {
      _users = (await ApiService.getUsers()).cast<Map<String, dynamic>>();
      notifyListeners();
    } catch (e) {
      print('Error loading users: $e');
      notifyListeners();
    }
  }

  Future<void> loadDevices() async {
    _isLoading = true;
    _error = null;
    notifyListeners();

    try {
      _devices = (await ApiService.getDevices()).cast<Map<String, dynamic>>();
      print('Devices loaded from API: ${_devices.length}');
      _isLoading = false;
      notifyListeners();
    } catch (e) {
      print('Error loading devices: $e');
      _error = e.toString();
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> createDevice(Map<String, dynamic> deviceData) async {
    try {
      final newDevice = await ApiService.createDevice(deviceData);
      _devices.add(newDevice);
      notifyListeners();
    } catch (e) {
      _error = e.toString();
      notifyListeners();
    }
  }

  Future<void> updateDevice(int id, Map<String, dynamic> deviceData) async {
    try {
      final updated = await ApiService.updateDevice(id, deviceData);
      final index = _devices.indexWhere((d) => d['id'] == id);
      if (index != -1) {
        _devices[index] = updated;
        notifyListeners();
      }
    } catch (e) {
      _error = e.toString();
      notifyListeners();
    }
  }

  Future<void> deleteDevice(int id) async {
    try {
      await ApiService.deleteDevice(id);
      _devices.removeWhere((d) => d['id'] == id);
      notifyListeners();
    } catch (e) {
      _error = e.toString();
      notifyListeners();
    }
  }

  Future<void> acknowledgeAlert(int alertId) async {
    try {
      await ApiService.acknowledgeAlert(alertId);
      _alerts.removeWhere((a) => a['id'] == alertId);
      notifyListeners();
    } catch (e) {
      _error = e.toString();
      notifyListeners();
    }
  }

  void _loadDemoData() {
    _dashboardData = {
      'total_animals': 142,
      'active_alerts': 3,
      'healthy_count': 138,
      'grazing_zones': 3,
    };
    _animals = _demoAnimals;
    notifyListeners();
  }

  void _loadDemoMapData() {
    _mapData = _demoAnimals.map((animal) {
      return {
        'id': animal['id'],
        'animal_id': animal['animal_id'],
        'name': animal['name'],
        'species': animal['species'],
        'breed': animal['breed'],
        'gender': animal['gender'],
        'status': animal['status'],
        'latitude': animal['latitude'],
        'longitude': animal['longitude'],
        'temperature': animal['temperature'],
        'heart_rate': animal['heart_rate'],
        'battery_level': animal['battery_level'],
        'image': animal['image'],
      };
    }).toList();
    notifyListeners();
  }

  static final List<Map<String, dynamic>> _demoAnimals = [
    {
      'id': 1,
      'animal_id': 'OA-2026-0001',
      'name': 'Al-Sahra',
      'species': 'Camel',
      'breed': 'Majaheem',
      'gender': 'Male',
      'status': 'Out of Range',
      'latitude': 24.7136,
      'longitude': 46.6753,
      'temperature': '37.2°C',
      'heart_rate': '48 BPM',
      'battery_level': 85,
      'image':
          'https://lh3.googleusercontent.com/aida-public/AB6AXuDATU_jJtuNTLI57i4Xas2WdVy_RBlq0A728QbQ9PYqDWx_2B7vi8a3Z6CQvpMZT-lQdHmDRjyysEfCx0y4Ar8NOtGgiueXoj71PheIARfeJJbxegIGf4fcb-NRTI02ZijL8nRSQUQSvHU7GeiTyQWXu1p4JzDCTMBAtpr7MrU3Tguo-2OFdOh_EOX_M2BENSH0te2TuceRXh_Uz9legD-BZD0AADZmZ9U-uylSFGsTVPh57ypdR8-FeQTgnxMJQ3orMlaDBTrLlSE',
    },
    {
      'id': 2,
      'animal_id': 'OA-2026-0002',
      'name': 'Desert Rose',
      'species': 'Camel',
      'breed': 'Wadhah',
      'gender': 'Female',
      'status': 'Grazing',
      'latitude': 24.7200,
      'longitude': 46.6800,
      'temperature': '38.1°C',
      'heart_rate': '42 BPM',
      'battery_level': 92,
      'image': null,
    },
    {
      'id': 3,
      'animal_id': 'OA-2026-0003',
      'name': 'Sand Storm',
      'species': 'Camel',
      'breed': 'Suhail',
      'gender': 'Male',
      'status': 'Resting',
      'latitude': 24.7050,
      'longitude': 46.6700,
      'temperature': '37.8°C',
      'heart_rate': '39 BPM',
      'battery_level': 78,
      'image': null,
    },
    {
      'id': 4,
      'animal_id': 'OA-2026-0004',
      'name': 'Golden Sand',
      'species': 'Camel',
      'breed': 'Majaheem',
      'gender': 'Female',
      'status': 'Grazing',
      'latitude': 24.7180,
      'longitude': 46.6850,
      'temperature': '38.4°C',
      'heart_rate': '40 BPM',
      'battery_level': 88,
      'image': null,
    },
    {
      'id': 5,
      'animal_id': 'OA-2026-0005',
      'name': 'Moon Walker',
      'species': 'Camel',
      'breed': 'Wadhah',
      'gender': 'Male',
      'status': 'Moving',
      'latitude': 24.7250,
      'longitude': 46.6900,
      'temperature': '39.0°C',
      'heart_rate': '50 BPM',
      'battery_level': 95,
      'image': null,
    },
  ];

  static final List<Map<String, dynamic>> _demoAlerts = [
    {
      'id': 1,
      'type': 'out_of_range',
      'animal_id': 'OA-2026-0001',
      'animal_name': 'Al-Sahra',
      'geofence_name': 'Zone A: Al-Dahna',
      'latitude': 24.7136,
      'longitude': 46.6753,
      'is_acknowledged': false,
      'triggered_at': DateTime.now()
          .subtract(const Duration(hours: 2))
          .toIso8601String(),
    },
    {
      'id': 2,
      'type': 'low_battery',
      'animal_id': 'OA-2026-0003',
      'animal_name': 'Sand Storm',
      'device_id': 'DEV-003',
      'battery_level': 15,
      'is_acknowledged': false,
      'triggered_at': DateTime.now()
          .subtract(const Duration(minutes: 30))
          .toIso8601String(),
    },
    {
      'id': 3,
      'type': 'high_temperature',
      'animal_id': 'OA-2026-0005',
      'animal_name': 'Moon Walker',
      'temperature': '40.2°C',
      'normal_temperature': '39.0°C',
      'is_acknowledged': false,
      'triggered_at': DateTime.now()
          .subtract(const Duration(hours: 1))
          .toIso8601String(),
    },
  ];

  static final List<Map<String, dynamic>> _demoGeofences = [
    {
      'id': 1,
      'name': 'Zone A: Al-Dahna',
      'coordinates': [
        [24.7200, 46.6700],
        [24.7200, 46.6900],
        [24.7000, 46.6900],
        [24.7000, 46.6700],
      ],
      'color': '#06402B',
      'alert_type': 'exit',
      'is_active': true,
    },
    {
      'id': 2,
      'name': 'Zone B: Empty Quarter',
      'coordinates': [
        [24.7400, 46.6800],
        [24.7400, 46.7000],
        [24.7200, 46.7000],
        [24.7200, 46.6800],
      ],
      'color': '#735c00',
      'alert_type': 'enter',
      'is_active': true,
    },
  ];

  List<Map<String, dynamic>> _vaccinations = [];
  List<Map<String, dynamic>> get vaccinations => _vaccinations;

  Future<void> loadVaccinations() async {
    try {
      _vaccinations = (await ApiService.getVaccinations())
          .cast<Map<String, dynamic>>();
      notifyListeners();
    } catch (e) {
      print('Error loading vaccinations: $e');
      _vaccinations = _demoVaccinations.cast<Map<String, dynamic>>();
      notifyListeners();
    }
  }

  Future<void> createVaccination(Map<String, dynamic> data) async {
    try {
      await ApiService.createVaccination(data);
      await loadVaccinations();
    } catch (e) {
      _error = e.toString();
      notifyListeners();
    }
  }

  static final List<Map<String, dynamic>> _demoVaccinations = [
    {
      'id': 1,
      'animal_id': 1,
      'animal_name': 'Al-Sahra',
      'vaccine_name': 'FMD Vaccine',
      'vaccination_type': 'initial',
      'dose_number': 1,
      'total_doses': 2,
      'scheduled_date': '2026-04-20',
      'status': 'scheduled',
    },
    {
      'id': 2,
      'animal_id': 2,
      'animal_name': 'Desert Rose',
      'vaccine_name': 'Clostridial',
      'vaccination_type': 'booster',
      'dose_number': 1,
      'total_doses': 1,
      'scheduled_date': '2026-04-18',
      'administered_date': '2026-04-10',
      'status': 'administered',
    },
  ];

  List<Map<String, dynamic>> get demoVaccinations => _demoVaccinations;

  static final List<Map<String, dynamic>> _demoAuctions = [
    {
      'id': 1,
      'title': 'Camel Majaheem - Premium Breeding',
      'animal_id': 1,
      'starting_price': 50000,
      'current_price': 55000,
      'reserve_price': 45000,
      'status': 'active',
      'starts_at': '2026-04-10 10:00:00',
      'ends_at': '2026-04-15 10:00:00',
    },
    {
      'id': 2,
      'title': 'Goat Boer - Show Quality',
      'animal_id': 10,
      'starting_price': 2500,
      'current_price': 3200,
      'reserve_price': 3000,
      'status': 'active',
      'starts_at': '2026-04-11 08:00:00',
      'ends_at': '2026-04-16 08:00:00',
    },
    {
      'id': 3,
      'title': 'Camel Wadhah - Racing Champion',
      'animal_id': 3,
      'starting_price': 75000,
      'current_price': 82000,
      'reserve_price': 70000,
      'status': 'sold',
      'starts_at': '2026-04-05 10:00:00',
      'ends_at': '2026-04-08 10:00:00',
    },
  ];

  List<Map<String, dynamic>> get demoAnimals => _demoAnimals;
  List<Map<String, dynamic>> get demoAlerts => _demoAlerts;
  List<Map<String, dynamic>> get demoGeofences => _demoGeofences;
  List<Map<String, dynamic>> get demoAuctions => _demoAuctions;

  Future<void> createAnimal(Map<String, dynamic> animalData) async {
    try {
      print('Creating animal with data: $animalData');
      final newAnimal = await ApiService.createAnimal(animalData);
      print('Animal created: $newAnimal');
      _animals.add(newAnimal);
      notifyListeners();
    } catch (e) {
      print('Error creating animal: $e');
      _error = e.toString();
      notifyListeners();
    }
  }

  Future<void> updateAnimal(int id, Map<String, dynamic> animalData) async {
    try {
      final updated = await ApiService.updateAnimal(id, animalData);
      final index = _animals.indexWhere((a) => a['id'] == id);
      if (index != -1) {
        _animals[index] = updated;
        notifyListeners();
      }
    } catch (e) {
      _error = e.toString();
      notifyListeners();
    }
  }

  Future<void> deleteAnimal(int id) async {
    try {
      await ApiService.deleteAnimal(id);
      _animals.removeWhere((a) => a['id'] == id);
      notifyListeners();
    } catch (e) {
      _error = e.toString();
      notifyListeners();
    }
  }

  List<Map<String, dynamic>> _medicalRecords = [];
  List<Map<String, dynamic>> get medicalRecords => _medicalRecords;

  Future<void> loadMedicalRecords() async {
    try {
      _medicalRecords = (await ApiService.getMedicalRecords())
          .cast<Map<String, dynamic>>();
      notifyListeners();
    } catch (e) {
      print('Error loading medical records: $e');
      _medicalRecords = _demoMedicalRecords.cast<Map<String, dynamic>>();
      notifyListeners();
    }
  }

  Future<void> createMedicalRecord(Map<String, dynamic> data) async {
    try {
      await ApiService.createMedicalRecord(data);
      await loadMedicalRecords();
    } catch (e) {
      _error = e.toString();
      notifyListeners();
    }
  }

  static final List<Map<String, dynamic>> _demoMedicalRecords = [
    {
      'id': 1,
      'animal_id': 1,
      'animal_name': 'Al-Sahra',
      'record_type': 'Checkup',
      'diagnosis': 'Healthy',
      'treatment': 'None',
      'record_date': '2026-04-10',
    },
    {
      'id': 2,
      'animal_id': 2,
      'animal_name': 'Desert Rose',
      'record_type': 'Treatment',
      'diagnosis': 'Heat stress',
      'treatment': 'IV fluids',
      'record_date': '2026-04-08',
    },
  ];

  List<Map<String, dynamic>> get demoMedicalRecords => _demoMedicalRecords;
}
